console.log("Welcome to Spotify");

// Initialize the variables
let songIndex = 0;
let audioElement = new Audio('assets/song.mp3');
let masterPlay = document.getElementById('masterPlay');
let myProgressBar = document.getElementById('myProgressBar');
let songItems = Array.from(document.getElementsByClassName('songItem'));

let songs = [
    { songName: "Heeriye", filePath: "assets/song.mp3", coverPath: "assets/img/cover.jpg" },
    { songName: "Heeriye", filePath: "assets/song.mp3", coverPath: "assets/img/cover.jpg" },
    { songName: "Heeriye", filePath: "assets/song.mp3", coverPath: "assets/img/cover.jpg" },
    { songName: "Heeriye", filePath: "assets/song.mp3", coverPath: "assets/img/cover.jpg" },
    { songName: "Heeriye", filePath: "assets/song.mp3", coverPath: "assets/img/cover.jpg" },
    { songName: "Heeriye", filePath: "assets/song.mp3", coverPath: "assets/img/cover.jpg" }
];

// Handle play/pause click
masterPlay.addEventListener('click', () => {
    if (audioElement.paused || audioElement.currentTime <= 0) {
        audioElement.play();
        masterPlay.classList.remove('fa-play');
        masterPlay.classList.add('fa-pause');
    } else {
        audioElement.pause();
        masterPlay.classList.remove('fa-pause');
        masterPlay.classList.add('fa-play');
    }
});

// Listen to audio element events
audioElement.addEventListener('timeupdate', () => {
    // Update progress bar
    let progress = parseInt((audioElement.currentTime / audioElement.duration) * 100);
    myProgressBar.value = progress;
});

// Handle progress bar change
myProgressBar.addEventListener('change', () => {
    audioElement.currentTime = myProgressBar.value * audioElement.duration / 100;
});

// Play song from the song list
songItems.forEach((element, index) => {
    element.addEventListener('click', (e) => {
        songIndex = index;
        audioElement.src = songs[songIndex].filePath;
        audioElement.play();
        masterPlay.classList.remove('fa-play');
        masterPlay.classList.add('fa-pause');
    });
});

// Debugging
audioElement.addEventListener('play', () => console.log('Audio playing'));
audioElement.addEventListener('pause', () => console.log('Audio paused'));
audioElement.addEventListener('timeupdate', () => console.log(`Current time: ${audioElement.currentTime}`));
